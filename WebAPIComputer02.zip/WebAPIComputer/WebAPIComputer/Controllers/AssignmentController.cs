﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using WebAPIComputer.Models;

namespace WebAPIComputer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssignmentController : ControllerBase
    {
        private IConfiguration _configuration;

        public AssignmentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetAssignment")]
        public JsonResult GetAssignment()
        {
            string query = "select * from ASSIGNMENT ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);

        }

        [HttpPost]
        [Route("AddAssignment")]
        public JsonResult AddAssignment([FromBody] Assignment assignment)
        {
            string query = "insert into ASSIGNMENT values(@IDAssignment, @IDLogin, @Lecturers, @Subject, @DMY, @ShiftTime, @CreatedAt, @UpdatedAt)";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDAssignment", assignment.IDAssignment);
                    myCommand.Parameters.AddWithValue("@IDLogin", assignment.IDLogin);
                    myCommand.Parameters.AddWithValue("@Lecturers", assignment.Lecturers);
                    myCommand.Parameters.AddWithValue("@Subject", assignment.Subject);
                    myCommand.Parameters.AddWithValue("@DMY", assignment.DMY);
                    myCommand.Parameters.AddWithValue("@ShiftTime", assignment.ShiftTime);
                    myCommand.Parameters.AddWithValue("@CreatedAt", assignment.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", assignment.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPut]
        [Route("UpdatedAssignment")]
        public JsonResult UpdatedAssignment([FromBody] Assignment assignment)
        {
            string query = "update ASSIGNMENT set IDLogin=@IDLogin, Lecturers=@Lecturers, Subject=@Subject, DMY=@DMY, ShiftTime=@ShiftTime, CreatedAt=@CreatedAt, UpdatedAt=@UpdatedAt where IDAssignment=@IDAssignment ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDAssignment", assignment.IDAssignment);
                    myCommand.Parameters.AddWithValue("@IDLogin", assignment.IDLogin);
                    myCommand.Parameters.AddWithValue("@Lecturers", assignment.Lecturers);
                    myCommand.Parameters.AddWithValue("@Subject", assignment.Subject);
                    myCommand.Parameters.AddWithValue("@DMY", assignment.DMY);
                    myCommand.Parameters.AddWithValue("@ShiftTime", assignment.ShiftTime);
                    myCommand.Parameters.AddWithValue("@CreatedAt", assignment.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", assignment.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Update Successful");
        }

        [HttpDelete("{IDAssignment}")]
        public JsonResult DeleteAssignment(string IDAssignment)
        {
            string query = "delete from ASSIGNMENT where IDAssignment=@IDAssignment";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDAssignment", IDAssignment);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Delete Successfully");
        }
    }
}
