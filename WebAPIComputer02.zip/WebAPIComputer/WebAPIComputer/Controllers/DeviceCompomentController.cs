﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using WebAPIComputer.Models;

namespace WebAPIComputer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeviceCompomentController : ControllerBase
    {
        private IConfiguration _configuration;

        public DeviceCompomentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetDeviceCompoment")]
        public JsonResult GetDeviceCompoment()
        {
            string query = "select * from DEVICEComponent ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);

        }

        [HttpPost]
        [Route("AddDeviceCompoment")]
        public JsonResult AddDeviceCompoment([FromBody] DeviceComponent deviceComponent)
        {
            string query = "insert into DEVICEComponent values(@IDDEVICEComponent, @IDDevice, @PCCODE, @DEVICEComponentName, @Status, @Note, @CreatedAt, @UpdatedAt)";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDEVICEComponent", deviceComponent.IdDeviceComponent);
                    myCommand.Parameters.AddWithValue("@IDDevice", deviceComponent.IdDevice);
                    myCommand.Parameters.AddWithValue("@PCCODE", deviceComponent.PcCode);
                    myCommand.Parameters.AddWithValue("@DEVICEComponentName", deviceComponent.DeviceComponentName);
                    myCommand.Parameters.AddWithValue("@Status", deviceComponent.Status);
                    myCommand.Parameters.AddWithValue("@Note", deviceComponent.Note);
                    myCommand.Parameters.AddWithValue("@CreatedAt", deviceComponent.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", deviceComponent.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPut]
        [Route("UpdatedDeviceCompoment")]
        public JsonResult UpdatedDeviceCompoment([FromBody] DeviceComponent deviceComponent)
        {
            string query = "update DEVICEComponent set IDDevice=@IDDevice, PCCODE=@PCCODE, DEVICEComponentName=@DEVICEComponentName, Status=@Status, Note=@Note, CreatedAt=@CreatedAt, UpdatedAt=@UpdatedAt where IDDEVICEComponent=@IDDEVICEComponent ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDEVICEComponent", deviceComponent.IdDeviceComponent);
                    myCommand.Parameters.AddWithValue("@IDDevice", deviceComponent.IdDevice);
                    myCommand.Parameters.AddWithValue("@PCCODE", deviceComponent.PcCode);
                    myCommand.Parameters.AddWithValue("@DEVICEComponentName", deviceComponent.DeviceComponentName);
                    myCommand.Parameters.AddWithValue("@Status", deviceComponent.Status);
                    myCommand.Parameters.AddWithValue("@Note", deviceComponent.Note);
                    myCommand.Parameters.AddWithValue("@CreatedAt", deviceComponent.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", deviceComponent.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Update Successful");
        }

        [HttpDelete("{IDDEVICEComponent}")]
        public JsonResult DeleteDeviceCompoment(string IDDEVICEComponent)
        {
            string query = "delete from DEVICEComponent where IDDEVICEComponent=@IDDEVICEComponent";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDEVICEComponent", IDDEVICEComponent);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Delete Successfully");
        }
    }
}
