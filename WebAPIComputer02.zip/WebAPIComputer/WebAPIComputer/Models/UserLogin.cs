﻿namespace WebAPIComputer.Models
{
    public class UserLogin
    {
        public int IdLogin { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
