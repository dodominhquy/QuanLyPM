﻿namespace WebAPIComputer.Models
{
    public class Device
    {
        public string IdDevice { get; set; }
        public string IdRoom { get; set; }
        public string PcCode { get; set; }
        public string NumberOfComputerComponents { get; set; }
        public int QuantityOfSoftware { get; set; }
        public string Status { get; set; }
        public string Note { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
