﻿namespace WebAPIComputer.Models
{
    public class DeviceComponent
    {
        public string IdDeviceComponent { get; set; }
        public string IdDevice { get; set; }
        public string PcCode { get; set; }
        public string DeviceComponentName { get; set; }
        public string Status { get; set; }
        public string Note { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
