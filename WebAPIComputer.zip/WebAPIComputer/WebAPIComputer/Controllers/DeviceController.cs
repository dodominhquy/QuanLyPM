﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using WebAPIComputer.Models;

namespace WebAPIComputer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeviceController : ControllerBase
    {
        private IConfiguration _configuration;

        public DeviceController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetDevice")]
        public JsonResult GetDevice()
        {
            string query = "select * from DEVICE ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);

        }

        [HttpPost]
        [Route("AddDevice")]
        public JsonResult AddDevice([FromBody] Device device)
        {
            string query = "insert into DEVICE values(@IDDevice, @IDRoom, @Monitor, @Keyboard, @Mouse, @PCcase, @QuantityOfSoftware, @Status, @Note, @CreatedAt, @UpdatedAt)";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDevice", device.IdDevice);
                    myCommand.Parameters.AddWithValue("@IDRoom", device.IdRoom);
                    myCommand.Parameters.AddWithValue("@Monitor", device.Monitor);
                    myCommand.Parameters.AddWithValue("@Keyboard", device.KeyBoard);
                    myCommand.Parameters.AddWithValue("@Mouse", device.Mouse);
                    myCommand.Parameters.AddWithValue("@PCcase", device.PcCase);
                    myCommand.Parameters.AddWithValue("@QuantityOfSoftware", device.QuantityOfSoftware);
                    myCommand.Parameters.AddWithValue("@Status", device.Status);
                    myCommand.Parameters.AddWithValue("@Note", device.Note);
                    myCommand.Parameters.AddWithValue("@CreatedAt", device.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", device.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPut]
        [Route("UpdatedDevice")]
        public JsonResult UpdatedRoom([FromBody] Device device)
        {
            string query = "update DEVICE set IDRoom=@IDRoom, Monitor=@Monitor, Keyboard=@Keyboard, Mouse=@Mouse, PCcase=@PCcase, QuantityOfSoftware=@QuantityOfSoftware, Status=@Status, Note=@Note, CreatedAt=@CreatedAt, UpdatedAt=@UpdatedAt where IDDevice=@IDDevice ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDevice", device.IdDevice);
                    myCommand.Parameters.AddWithValue("@IDRoom", device.IdRoom);
                    myCommand.Parameters.AddWithValue("@Monitor", device.Monitor);
                    myCommand.Parameters.AddWithValue("@Keyboard", device.KeyBoard);
                    myCommand.Parameters.AddWithValue("@Mouse", device.Mouse);
                    myCommand.Parameters.AddWithValue("@PCcase", device.PcCase);
                    myCommand.Parameters.AddWithValue("@QuantityOfSoftware", device.QuantityOfSoftware);
                    myCommand.Parameters.AddWithValue("@Status", device.Status);
                    myCommand.Parameters.AddWithValue("@Note", device.Note);
                    myCommand.Parameters.AddWithValue("@CreatedAt", device.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", device.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Update Successful");
        }

        [HttpDelete("{IdDevice}")]
        public JsonResult DeleteRoom(string IdDevice)
        {
            string query = "delete from DEVICE where IDDevice=@IDDevice";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDevice", IdDevice);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Delete Successfully");
        }
    }
}
