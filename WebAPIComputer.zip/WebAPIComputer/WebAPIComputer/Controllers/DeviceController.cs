﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using WebAPIComputer.Models;

namespace WebAPIComputer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeviceController : ControllerBase
    {
        private IConfiguration _configuration;

        public DeviceController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetDevice")]
        public JsonResult GetDevice()
        {
            string query = "select * from DEVICE ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);

        }

        [HttpPost]
        [Route("AddDevice")]
        public JsonResult AddDevice([FromBody] Device device)
        {
            string query = "insert into DEVICE values(@IDDevice, @IDRoom, @PCCODE, @NumberOfComputerComponents, @QuantityOfSoftware, @Status, @Note, @CreatedAt, @UpdatedAt)";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDevice", device.IdDevice);
                    myCommand.Parameters.AddWithValue("@IDRoom", device.IdRoom);
                    myCommand.Parameters.AddWithValue("@PCCODE", device.PcCode);
                    myCommand.Parameters.AddWithValue("@NumberOfComputerComponents", device.NumberOfComputerComponents);
                    myCommand.Parameters.AddWithValue("@QuantityOfSoftware", device.QuantityOfSoftware);
                    myCommand.Parameters.AddWithValue("@Status", device.Status);
                    myCommand.Parameters.AddWithValue("@Note", device.Note);
                    myCommand.Parameters.AddWithValue("@CreatedAt", device.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", device.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPut]
        [Route("UpdatedDevice")]
        public JsonResult UpdatedDevice([FromBody] Device device)
        {
            string query = "update DEVICE set IDRoom=@IDRoom, PCCODE=@PCCODE, NumberOfComputerComponents=@NumberOfComputerComponents, QuantityOfSoftware=@QuantityOfSoftware, Status=@Status, Note=@Note, CreatedAt=@CreatedAt, UpdatedAt=@UpdatedAt where IDDevice=@IDDevice ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDevice", device.IdDevice);
                    myCommand.Parameters.AddWithValue("@IDRoom", device.IdRoom);
                    myCommand.Parameters.AddWithValue("@PCCODE", device.PcCode);
                    myCommand.Parameters.AddWithValue("@NumberOfComputerComponents", device.NumberOfComputerComponents);
                    myCommand.Parameters.AddWithValue("@QuantityOfSoftware", device.QuantityOfSoftware);
                    myCommand.Parameters.AddWithValue("@Status", device.Status);
                    myCommand.Parameters.AddWithValue("@Note", device.Note);
                    myCommand.Parameters.AddWithValue("@CreatedAt", device.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", device.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Update Successful");
        }

        [HttpDelete("{IDDevice}")]
        public JsonResult DeleteDevice(string IDDevice)
        {
            string query = "delete from DEVICE where IDDevice=@IDDevice";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDDevice", IDDevice);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Delete Successfully");
        }
    }
}
