﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using WebAPIComputer.Models;

namespace WebAPIComputer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration _configuration;

        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetLogin")]
        public JsonResult GetLogin()
        {
            string query = "select * from LOGIN ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using(SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPost]
        [Route("AddLogin")]
        public JsonResult AddLogin([FromBody] UserLogin userLogin)
        {
            string query = "insert into LOGIN values(@IDLogin, @Username, @Password, @CreatedAt, @UpdatedAt)";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDLogin", userLogin.IdLogin);
                    myCommand.Parameters.AddWithValue("@Username", userLogin.Username);
                    myCommand.Parameters.AddWithValue("@Password", userLogin.Password);
                    myCommand.Parameters.AddWithValue("@CreatedAt", userLogin.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", userLogin.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Add Successfully");
        }

        [HttpDelete]
        [Route("DeleteLogin")]
        public JsonResult DeleteLogin(int IdLogin)
        {
            string query = "delete from LOGIN where IDLogin=@IDLogin";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDLogin", IdLogin);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Delete Successfully");
        }

        [HttpPost]
        [Route("Login")]
        public JsonResult Login([FromBody] UserLogin userLogin)
        {

            string query = "select * from LOGIN where Username=@Username and Password=@Password";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            
                using (SqlConnection myConn = new SqlConnection(sqlDatasource))
                {
                    myConn.Open();
                    using (SqlCommand myCommand = new SqlCommand(query, myConn))
                    {
                        myCommand.Parameters.AddWithValue("@Username", userLogin.Username);
                        myCommand.Parameters.AddWithValue("@Password", userLogin.Password);
                        myReader = myCommand.ExecuteReader();
                        dt.Load(myReader);
                        myReader.Close();
                        myConn.Close();
                    }
            }

            return new JsonResult(dt);

        }

        [HttpPut]
        [Route("UpdatedLogin")]
        public JsonResult UpdatedLogin(int IdLogin, [FromBody] UserLogin userLogin)
        {
            string query = "update LOGIN set Username=@Username, Password=@Password, CreatedAt=@CreatedAt, UpdatedAt=@UpdatedAt where IDLogin=@IDLogin ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDLogin", userLogin.IdLogin);
                    myCommand.Parameters.AddWithValue("@Username", userLogin.Username);
                    myCommand.Parameters.AddWithValue("@Password", userLogin.Password);
                    myCommand.Parameters.AddWithValue("@CreatedAt", userLogin.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", userLogin.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }
    }
}
