﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using WebAPIComputer.Models;

namespace WebAPIComputer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        private IConfiguration _configuration;

        public RoomController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetRoom")]
        public JsonResult GetRoom()
        {
            string query = "select * from ROOM ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);

        }

        [HttpGet("{IdRoom}")]
        public JsonResult GetRoomID(string IdRoom)
        {
            string query = "select * from ROOM where IDroom=@IDroom";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDroom", IdRoom);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPost]
        [Route("AddRoom")]
        public JsonResult AddRoom([FromBody] Room room)
        {
            string query = "insert into ROOM values(@IDRoom, @RoomName, @Location, @Subject, @DeviceQuantity, @IDAssignment, @CreatedAt, @UpdatedAt)";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDRoom", room.IdRoom);
                    myCommand.Parameters.AddWithValue("@RoomName", room.RoomName);
                    myCommand.Parameters.AddWithValue("@Location", room.Location);
                    myCommand.Parameters.AddWithValue("@Subject", room.Subject);
                    myCommand.Parameters.AddWithValue("@DeviceQuantity", room.DeviceQuantity);
                    myCommand.Parameters.AddWithValue("@IDAssignment", room.IDAssignment);
                    myCommand.Parameters.AddWithValue("@CreatedAt", room.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", room.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult(dt);
        }

        [HttpPut]
        [Route("UpdatedRoom")]
        public JsonResult UpdatedRoom([FromBody] Room room)
        {
            string query = "update ROOM set RoomName=@RoomName, Location=@Location, Subject=@Subject, DeviceQuantity=@DeviceQuantity, IDAssignment=@IDAssignment, CreatedAt=@CreatedAt, UpdatedAt=@UpdatedAt where IDRoom=@IDRoom ";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDRoom", room.IdRoom);
                    myCommand.Parameters.AddWithValue("@RoomName", room.RoomName);
                    myCommand.Parameters.AddWithValue("@Location", room.Location);
                    myCommand.Parameters.AddWithValue("@Subject", room.Subject);
                    myCommand.Parameters.AddWithValue("@DeviceQuantity", room.DeviceQuantity);
                    myCommand.Parameters.AddWithValue("@IDAssignment", room.IDAssignment);
                    myCommand.Parameters.AddWithValue("@CreatedAt", room.CreatedAt);
                    myCommand.Parameters.AddWithValue("@UpdatedAt", room.UpdatedAt);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Update Successful");
        }

        [HttpDelete("{IdRoom}")]
        public JsonResult DeleteRoom(string IdRoom)
        {
            string query = "delete from ROOM where IDRoom=@IDRoom";
            DataTable dt = new DataTable();
            string sqlDatasource = _configuration.GetConnectionString("qlpmDBCon");
            SqlDataReader myReader;
            using (SqlConnection myConn = new SqlConnection(sqlDatasource))
            {
                myConn.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConn))
                {
                    myCommand.Parameters.AddWithValue("@IDRoom", IdRoom);
                    myReader = myCommand.ExecuteReader();
                    dt.Load(myReader);
                    myReader.Close();
                    myConn.Close();
                }
            }

            return new JsonResult("Delete Successfully");
        }

    }
}
