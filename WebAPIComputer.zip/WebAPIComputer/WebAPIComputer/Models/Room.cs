﻿namespace WebAPIComputer.Models
{
    public class Room
    {
        public string IdRoom { get; set; }
        public string RoomName { get; set; }
        public int DeviceQuantity { get; set; }

        public int IDAssignment { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set;}

    }
}
