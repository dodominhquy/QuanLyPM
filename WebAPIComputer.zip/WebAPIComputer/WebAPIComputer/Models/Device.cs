﻿namespace WebAPIComputer.Models
{
    public class Device
    {
        public string IdDevice { get; set; }
        public string IdRoom { get; set; }
        public int Monitor { get; set; }
        public int KeyBoard { get; set; }
        public int Mouse { get; set; }
        public int PcCase { get; set; }
        public int QuantityOfSoftware { get; set; }
        public string Status { get; set; }
        public string Note { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
