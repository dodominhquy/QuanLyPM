﻿namespace WebAPIComputer.Models
{
    public class Assignment
    {
        public int IDAssignment { get; set; }
        public int IDLogin { get; set; }
        public string Lecturers { get; set; }
        public string Subject { get; set; }
        public DateTime DMY { get; set; }
        public string ShiftTime { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
